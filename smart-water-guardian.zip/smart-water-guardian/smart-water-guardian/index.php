<?php
/**
 * Smart Water Guardian - Landing Page
 * Clean Splash with Water Droplet Loading
 */

session_start();

// If user is already logged in, redirect to dashboard
if (isset($_SESSION['user_id']) && $_SESSION['logged_in']) {
    header('Location: pages/dashboard.php');
    exit();
}

$page_title = 'Smart Water Guardian - Save Water, Save Life';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Smart Water Guardian - Save Water, Save Life</title>
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        /* ============================================================
                   LANDING PAGE - CLEAN SPLASH WITH SVG BACKGROUND
                   ============================================================ */
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            overflow-x: hidden;
            background: #0a0e1a;
            color: #ffffff;
        }
        
        /* ============================================================
                   SVG BACKGROUND
                   ============================================================ */
        .svg-bg {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            z-index: 0;
            pointer-events: none;
            overflow: hidden;
        }
        
        .svg-bg svg {
            width: 100%;
            height: 100%;
            opacity: 0.6;
        }
        
        /* ============================================================
                   SPLASH SCREEN - WATER DROPLET LOADING
                   ============================================================ */
        .splash-screen {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 9999;
            background: #0a0e1a;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            transition: all 1s cubic-bezier(0.4, 0, 0.2, 1);
            overflow: hidden;
        }
        
        .splash-screen.hidden {
            opacity: 0;
            pointer-events: none;
            transform: scale(1.05);
        }
        
        /* Splash SVG Background */
        .splash-svg-bg {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            pointer-events: none;
            opacity: 0.3;
        }
        
        .splash-svg-bg svg {
            width: 100%;
            height: 100%;
        }
        
        /* ============================================================
                   WATER DROPLET LOADER
                   ============================================================ */
        .splash-loader-wrapper {
            position: relative;
            z-index: 2;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        /* Water Drop Container */
        .drop-container {
            position: relative;
            width: 120px;
            height: 150px;
            margin-bottom: 10px;
        }
        
        /* Water Drop Shape */
        .water-drop {
            position: relative;
            width: 80px;
            height: 80px;
            margin: 0 auto;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            border-radius: 50% 50% 50% 50% / 30% 30% 70% 70%;
            transform: rotate(45deg);
            box-shadow: 0 0 60px rgba(26, 143, 196, 0.15);
            animation: dropPulse 2s ease-in-out infinite;
        }
        
        @keyframes dropPulse {
            0%, 100% { transform: rotate(45deg) scale(1); box-shadow: 0 0 60px rgba(26, 143, 196, 0.15); }
            50% { transform: rotate(45deg) scale(1.04); box-shadow: 0 0 80px rgba(26, 143, 196, 0.25); }
        }
        
        .water-drop::before {
            content: '';
            position: absolute;
            top: 15%;
            left: 25%;
            width: 25%;
            height: 25%;
            background: radial-gradient(circle at center, rgba(255, 255, 255, 0.3), transparent);
            border-radius: 50%;
        }
        
        .water-drop .drop-icon {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) rotate(-45deg);
            color: white;
            font-size: 30px;
            opacity: 0.8;
        }
        
        /* Water Drop Filling Animation */
        .drop-fill {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 0%;
            background: linear-gradient(180deg, rgba(26, 143, 196, 0.05), rgba(26, 143, 196, 0.2));
            border-radius: 0 0 50% 50% / 0 0 70% 70%;
            transition: height 0.1s linear;
            overflow: hidden;
        }
        
        .drop-fill::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 100%;
            background: linear-gradient(180deg, rgba(26, 143, 196, 0.2), rgba(91, 45, 142, 0.2));
            animation: fillWave 1.5s ease-in-out infinite;
        }
        
        @keyframes fillWave {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }
        
        /* Percentage Text */
        .splash-percentage {
            font-size: 48px;
            font-weight: 800;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-top: 10px;
            font-variant-numeric: tabular-nums;
            letter-spacing: -2px;
        }
        
        .splash-percentage .percent-symbol {
            font-size: 28px;
            -webkit-text-fill-color: rgba(255, 255, 255, 0.15);
        }
        
        /* Loading Text */
        .splash-loading-text {
            color: rgba(255, 255, 255, 0.15);
            font-size: 14px;
            letter-spacing: 4px;
            text-transform: uppercase;
            margin-top: 8px;
            font-weight: 300;
        }
        
        .splash-loading-text .dot {
            display: inline-block;
            animation: dotPulse 1.4s ease-in-out infinite;
        }
        .splash-loading-text .dot:nth-child(2) { animation-delay: 0.2s; }
        .splash-loading-text .dot:nth-child(3) { animation-delay: 0.4s; }
        
        @keyframes dotPulse {
            0%, 80%, 100% { opacity: 0.2; }
            40% { opacity: 1; }
        }
        
        /* PROCEED BUTTON */
        .splash-proceed-btn {
            margin-top: 30px;
            padding: 14px 48px;
            border: none;
            border-radius: 50px;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            color: white;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 4px 30px rgba(26, 143, 196, 0.15);
            opacity: 0;
            transform: translateY(20px) scale(0.9);
            pointer-events: none;
            display: flex;
            align-items: center;
            gap: 12px;
            letter-spacing: 0.5px;
        }
        
        .splash-proceed-btn.show {
            opacity: 1;
            transform: translateY(0) scale(1);
            pointer-events: auto;
        }
        
        .splash-proceed-btn:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 50px rgba(26, 143, 196, 0.3);
        }
        
        .splash-proceed-btn:active {
            transform: scale(0.97);
        }
        
        .splash-proceed-btn i {
            font-size: 20px;
            transition: transform 0.3s ease;
        }
        
        .splash-proceed-btn:hover i {
            transform: translateX(5px);
        }
        
        /* ============================================================
                   NAVIGATION
                   ============================================================ */
        .landing-nav {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(10, 14, 26, 0.85);
            backdrop-filter: blur(20px);
            padding: 14px 40px;
            z-index: 1000;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.3s ease;
        }
        
        .landing-nav.scrolled {
            background: rgba(10, 14, 26, 0.95);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.3);
        }
        
        .landing-nav .brand {
            font-size: 20px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .landing-nav .brand .brand-icon {
            width: 36px;
            height: 36px;
            border-radius: 10px;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 16px;
        }
        
        .landing-nav .brand .brand-text {
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .landing-nav .nav-actions {
            display: flex;
            gap: 12px;
            align-items: center;
        }
        
        .landing-nav .nav-actions a {
            padding: 10px 24px;
            border-radius: 50px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            font-size: 14px;
        }
        
        .btn-login {
            color: rgba(255, 255, 255, 0.4);
            border: 1px solid rgba(255, 255, 255, 0.06);
        }
        
        .btn-login:hover {
            color: white;
            border-color: rgba(255, 255, 255, 0.12);
            background: rgba(255, 255, 255, 0.03);
            transform: translateY(-2px);
        }
        
        .btn-register-nav {
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            color: white;
            box-shadow: 0 4px 20px rgba(26, 143, 196, 0.15);
        }
        
        .btn-register-nav:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(26, 143, 196, 0.25);
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
            padding: 8px;
        }
        
        /* ============================================================
                   HERO SECTION
                   ============================================================ */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 100px 20px 60px;
            position: relative;
            overflow: hidden;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
            max-width: 900px;
            text-align: center;
        }
        
        .hero-badge {
            display: inline-block;
            background: rgba(26, 143, 196, 0.08);
            padding: 8px 28px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 30px;
            border: 1px solid rgba(26, 143, 196, 0.06);
            color: #5ba3c4;
        }
        
        .hero-badge i {
            margin-right: 8px;
            color: #5ba3c4;
        }
        
        .hero h1 {
            font-size: 60px;
            font-weight: 900;
            line-height: 1.08;
            margin-bottom: 24px;
            letter-spacing: -2px;
        }
        
        .hero h1 .highlight {
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .hero h1 .highlight-green {
            background: linear-gradient(135deg, #2d9c7a, #1a8fc4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .hero p {
            font-size: 20px;
            color: rgba(255, 255, 255, 0.4);
            max-width: 650px;
            margin: 0 auto 36px;
            line-height: 1.8;
            font-weight: 300;
        }
        
        .hero-buttons {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .hero-buttons .btn {
            padding: 16px 40px;
            border-radius: 50px;
            font-size: 17px;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            color: white;
            box-shadow: 0 4px 30px rgba(26, 143, 196, 0.15);
        }
        
        .btn-primary:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 50px rgba(26, 143, 196, 0.25);
        }
        
        .btn-outline {
            background: rgba(255, 255, 255, 0.02);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }
        
        .btn-outline:hover {
            background: rgba(255, 255, 255, 0.05);
            border-color: rgba(255, 255, 255, 0.12);
            transform: translateY(-3px);
        }
        
        .hero-stats {
            display: flex;
            gap: 60px;
            justify-content: center;
            margin-top: 50px;
            padding-top: 35px;
            border-top: 1px solid rgba(255, 255, 255, 0.03);
        }
        
        .hero-stats .stat-item {
            text-align: center;
        }
        
        .hero-stats .stat-number {
            display: block;
            font-size: 42px;
            font-weight: 800;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1;
        }
        
        .hero-stats .stat-number .percent {
            font-size: 24px;
            -webkit-text-fill-color: rgba(255, 255, 255, 0.1);
        }
        
        .hero-stats .stat-label {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.25);
            margin-top: 4px;
            font-weight: 400;
        }
        
        .hero-stats .stat-label i {
            margin-right: 4px;
            color: #1a8fc4;
        }
        
        /* ============================================================
                   TESTIMONIALS SECTION
                   ============================================================ */
        .testimonials-section {
            padding: 100px 40px;
            background: #0a0e1a;
            position: relative;
        }
        
        .testimonials-section .container {
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }
        
        .testimonials-section .section-header {
            text-align: center;
            margin-bottom: 60px;
        }
        
        .testimonials-section .section-header h2 {
            font-size: 40px;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff, rgba(255, 255, 255, 0.6));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }
        
        .testimonials-section .section-header p {
            color: rgba(255, 255, 255, 0.25);
            font-size: 18px;
        }
        
        .testimonials-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }
        
        .testimonial-card {
            background: rgba(255, 255, 255, 0.015);
            padding: 32px 28px;
            border-radius: 20px;
            border: 1px solid rgba(255, 255, 255, 0.03);
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            text-align: center;
        }
        
        .testimonial-card:hover {
            transform: translateY(-10px);
            border-color: rgba(26, 143, 196, 0.08);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        }
        
        .testimonial-card .avatar {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            margin: 0 auto 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            font-weight: 700;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        
        .testimonial-card:hover .avatar {
            transform: scale(1.06);
        }
        
        .testimonial-card .stars {
            color: #c8a830;
            font-size: 16px;
            margin-bottom: 12px;
            letter-spacing: 3px;
        }
        
        .testimonial-card .quote {
            color: rgba(255, 255, 255, 0.45);
            font-size: 15px;
            line-height: 1.8;
            font-style: italic;
            margin-bottom: 16px;
        }
        
        .testimonial-card .author {
            font-weight: 700;
            color: rgba(255, 255, 255, 0.9);
            font-size: 16px;
        }
        
        .testimonial-card .role {
            font-size: 13px;
            color: rgba(255, 255, 255, 0.2);
            margin-top: 2px;
        }
        
        .avatar-color-1 { background: linear-gradient(135deg, #1a8fc4, #0f5a7a); }
        .avatar-color-2 { background: linear-gradient(135deg, #5b2d8e, #3a1a5c); }
        .avatar-color-3 { background: linear-gradient(135deg, #2d9c7a, #1a6b55); }
        .avatar-color-4 { background: linear-gradient(135deg, #c45a3a, #8a3a22); }
        .avatar-color-5 { background: linear-gradient(135deg, #c8a830, #8a7220); }
        .avatar-color-6 { background: linear-gradient(135deg, #c43a6a, #8a224a); }
        
        /* ============================================================
                   FEATURES SECTION
                   ============================================================ */
        .features-section {
            padding: 100px 40px;
            background: #0d111f;
            position: relative;
        }
        
        .features-section .container {
            max-width: 1200px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }
        
        .features-section .section-header {
            text-align: center;
            margin-bottom: 60px;
        }
        
        .features-section .section-header h2 {
            font-size: 40px;
            font-weight: 800;
            background: linear-gradient(135deg, #ffffff, rgba(255, 255, 255, 0.6));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 12px;
        }
        
        .features-section .section-header p {
            color: rgba(255, 255, 255, 0.25);
            font-size: 18px;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 30px;
        }
        
        .feature-card {
            background: rgba(255, 255, 255, 0.015);
            padding: 40px 30px;
            border-radius: 20px;
            text-align: center;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(255, 255, 255, 0.03);
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            border-color: rgba(26, 143, 196, 0.06);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.2);
        }
        
        .feature-card .icon-wrapper {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background: rgba(26, 143, 196, 0.04);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 16px;
            font-size: 30px;
        }
        
        .feature-card h3 {
            font-size: 20px;
            font-weight: 700;
            color: rgba(255, 255, 255, 0.9);
            margin-bottom: 8px;
        }
        
        .feature-card p {
            color: rgba(255, 255, 255, 0.3);
            font-size: 15px;
            line-height: 1.7;
        }
        
        /* ============================================================
                   CTA SECTION
                   ============================================================ */
        .cta-section {
            padding: 80px 40px;
            background: linear-gradient(135deg, #0a0e1a, #0d111f);
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.015);
            border-bottom: 1px solid rgba(255, 255, 255, 0.015);
        }
        
        .cta-section .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .cta-section h2 {
            font-size: 36px;
            font-weight: 800;
            color: white;
            margin-bottom: 12px;
        }
        
        .cta-section h2 span {
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .cta-section p {
            color: rgba(255, 255, 255, 0.3);
            font-size: 18px;
            margin-bottom: 30px;
        }
        
        .cta-section .btn {
            padding: 16px 48px;
            border-radius: 50px;
            font-size: 18px;
            font-weight: 600;
            text-decoration: none;
            background: linear-gradient(135deg, #1a8fc4, #5b2d8e);
            color: white;
            box-shadow: 0 4px 30px rgba(26, 143, 196, 0.15);
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }
        
        .cta-section .btn:hover {
            transform: translateY(-3px) scale(1.02);
            box-shadow: 0 8px 50px rgba(26, 143, 196, 0.25);
        }
        
        /* ============================================================
                   FOOTER
                   ============================================================ */
        .footer {
            background: #05080f;
            color: rgba(255, 255, 255, 0.2);
            padding: 40px;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.015);
        }
        
        .footer .footer-links {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }
        
        .footer .footer-links a {
            color: rgba(255, 255, 255, 0.15);
            text-decoration: none;
            font-size: 13px;
            transition: color 0.3s ease;
        }
        
        .footer .footer-links a:hover {
            color: rgba(255, 255, 255, 0.4);
        }
        
        .footer p {
            font-size: 14px;
            color: rgba(255, 255, 255, 0.1);
        }
        
        /* ============================================================
                   RESPONSIVE
                   ============================================================ */
        @media (max-width: 992px) {
            .features-grid { grid-template-columns: repeat(2, 1fr); }
            .testimonials-grid { grid-template-columns: repeat(2, 1fr); }
            .hero h1 { font-size: 44px; }
            .hero-stats { gap: 30px; }
            .hero-stats .stat-number { font-size: 34px; }
        }
        
        @media (max-width: 768px) {
            .landing-nav {
                padding: 12px 20px;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .landing-nav .nav-actions {
                display: none;
            }
            
            .landing-nav .nav-actions.open {
                display: flex;
                flex-direction: column;
                position: absolute;
                top: 70px;
                left: 20px;
                right: 20px;
                background: rgba(10, 14, 26, 0.98);
                padding: 20px;
                border-radius: 16px;
                border: 1px solid rgba(255, 255, 255, 0.04);
            }
            
            .hero h1 { font-size: 32px; letter-spacing: -1px; }
            .hero p { font-size: 16px; }
            .hero-stats { flex-direction: column; gap: 16px; border-top: none; padding-top: 0; margin-top: 30px; }
            
            .features-grid { grid-template-columns: 1fr; }
            .testimonials-grid { grid-template-columns: 1fr; }
            .testimonials-section { padding: 60px 20px; }
            .features-section { padding: 60px 20px; }
            .cta-section { padding: 60px 20px; }
            
            .features-section .section-header h2 { font-size: 28px; }
            .testimonials-section .section-header h2 { font-size: 28px; }
            .cta-section h2 { font-size: 28px; }
            
            .hero-buttons .btn {
                width: 100%;
                justify-content: center;
            }
            
            .footer .footer-links { gap: 16px; }
            .footer .footer-links a { font-size: 12px; }
            
            .drop-container { width: 90px; height: 120px; }
            .water-drop { width: 60px; height: 60px; }
            .water-drop .drop-icon { font-size: 22px; }
            .splash-percentage { font-size: 36px; }
            .splash-proceed-btn { padding: 12px 32px; font-size: 16px; }
        }
        
        @media (max-width: 480px) {
            .hero h1 { font-size: 26px; }
            .hero-stats .stat-number { font-size: 28px; }
            .landing-nav .brand .brand-text { font-size: 16px; }
            .landing-nav .brand .brand-icon { width: 30px; height: 30px; font-size: 13px; }
            
            .drop-container { width: 70px; height: 100px; }
            .water-drop { width: 48px; height: 48px; }
            .water-drop .drop-icon { font-size: 18px; }
            .splash-percentage { font-size: 28px; }
            .splash-proceed-btn { padding: 10px 24px; font-size: 14px; }
            .splash-proceed-btn i { font-size: 16px; }
            
            .testimonial-card .avatar { width: 60px; height: 60px; font-size: 24px; }
        }
    </style>
</head>
<body>

    <!-- ============================================================
    SVG BACKGROUND - CLEAN WATER PATTERN
    ============================================================ -->
    <div class="svg-bg">
        <svg viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
            <defs>
                <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#0a0e1a;stop-opacity:1" />
                    <stop offset="100%" style="stop-color:#0d1b2a;stop-opacity:1" />
                </linearGradient>
                <linearGradient id="waveGrad1" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#1a8fc4;stop-opacity:0.08" />
                    <stop offset="50%" style="stop-color:#5b2d8e;stop-opacity:0.05" />
                    <stop offset="100%" style="stop-color:#1a8fc4;stop-opacity:0.08" />
                </linearGradient>
                <linearGradient id="waveGrad2" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" style="stop-color:#5b2d8e;stop-opacity:0.04" />
                    <stop offset="50%" style="stop-color:#1a8fc4;stop-opacity:0.06" />
                    <stop offset="100%" style="stop-color:#5b2d8e;stop-opacity:0.04" />
                </linearGradient>
            </defs>
            
            <!-- Background -->
            <rect width="1200" height="800" fill="url(#bgGrad)"/>
            
            <!-- Wave 1 -->
            <path d="M0,400 C200,350 400,450 600,400 C800,350 1000,450 1200,400 L1200,800 L0,800 Z" 
                  fill="url(#waveGrad1)">
                <animate attributeName="d" 
                         values="M0,400 C200,350 400,450 600,400 C800,350 1000,450 1200,400 L1200,800 L0,800 Z;
                                 M0,420 C200,370 400,470 600,420 C800,370 1000,470 1200,420 L1200,800 L0,800 Z;
                                 M0,400 C200,350 400,450 600,400 C800,350 1000,450 1200,400 L1200,800 L0,800 Z" 
                         dur="12s" repeatCount="indefinite"/>
            </path>
            
            <!-- Wave 2 -->
            <path d="M0,450 C200,400 400,500 600,450 C800,400 1000,500 1200,450 L1200,800 L0,800 Z" 
                  fill="url(#waveGrad2)">
                <animate attributeName="d" 
                         values="M0,450 C200,400 400,500 600,450 C800,400 1000,500 1200,450 L1200,800 L0,800 Z;
                                 M0,470 C200,420 400,520 600,470 C800,420 1000,520 1200,470 L1200,800 L0,800 Z;
                                 M0,450 C200,400 400,500 600,450 C800,400 1000,500 1200,450 L1200,800 L0,800 Z" 
                         dur="16s" repeatCount="indefinite"/>
            </path>
            
            <!-- Wave 3 -->
            <path d="M0,500 C200,450 400,550 600,500 C800,450 1000,550 1200,500 L1200,800 L0,800 Z" 
                  fill="url(#waveGrad1)" opacity="0.5">
                <animate attributeName="d" 
                         values="M0,500 C200,450 400,550 600,500 C800,450 1000,550 1200,500 L1200,800 L0,800 Z;
                                 M0,520 C200,470 400,570 600,520 C800,470 1000,570 1200,520 L1200,800 L0,800 Z;
                                 M0,500 C200,450 400,550 600,500 C800,450 1000,550 1200,500 L1200,800 L0,800 Z" 
                         dur="20s" repeatCount="indefinite"/>
            </path>
            
            <!-- Water Droplets SVG -->
            <circle cx="100" cy="150" r="3" fill="rgba(26,143,196,0.08)">
                <animate attributeName="cy" values="150;100;150" dur="8s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.08;0.2;0.08" dur="8s" repeatCount="indefinite"/>
            </circle>
            <circle cx="300" cy="200" r="4" fill="rgba(91,45,142,0.06)">
                <animate attributeName="cy" values="200;140;200" dur="10s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.06;0.18;0.06" dur="10s" repeatCount="indefinite"/>
            </circle>
            <circle cx="500" cy="120" r="2" fill="rgba(26,143,196,0.1)">
                <animate attributeName="cy" values="120;70;120" dur="7s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.1;0.25;0.1" dur="7s" repeatCount="indefinite"/>
            </circle>
            <circle cx="750" cy="180" r="3.5" fill="rgba(91,45,142,0.07)">
                <animate attributeName="cy" values="180;120;180" dur="9s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.07;0.2;0.07" dur="9s" repeatCount="indefinite"/>
            </circle>
            <circle cx="950" cy="140" r="2.5" fill="rgba(26,143,196,0.09)">
                <animate attributeName="cy" values="140;80;140" dur="11s" repeatCount="indefinite"/>
                <animate attributeName="opacity" values="0.09;0.22;0.09" dur="11s" repeatCount="indefinite"/>
            </circle>
            
            <!-- Small dots pattern -->
            <circle cx="50" cy="300" r="1.5" fill="rgba(255,255,255,0.02)"/>
            <circle cx="200" cy="280" r="1" fill="rgba(255,255,255,0.015)"/>
            <circle cx="400" cy="320" r="1.5" fill="rgba(255,255,255,0.02)"/>
            <circle cx="600" cy="290" r="1" fill="rgba(255,255,255,0.015)"/>
            <circle cx="800" cy="310" r="1.5" fill="rgba(255,255,255,0.02)"/>
            <circle cx="1000" cy="285" r="1" fill="rgba(255,255,255,0.015)"/>
            <circle cx="1100" cy="300" r="1.5" fill="rgba(255,255,255,0.02)"/>
        </svg>
    </div>

    <!-- ============================================================
    SPLASH SCREEN - WATER DROPLET LOADING
    ============================================================ -->
    <div class="splash-screen" id="splashScreen">
        <!-- Splash SVG Background -->
        <div class="splash-svg-bg">
            <svg viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
                <defs>
                    <linearGradient id="splashGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:#0a0e1a;stop-opacity:1" />
                        <stop offset="100%" style="stop-color:#0d1b2a;stop-opacity:1" />
                    </linearGradient>
                </defs>
                <rect width="1200" height="800" fill="url(#splashGrad)"/>
                <circle cx="600" cy="400" r="200" fill="rgba(26,143,196,0.02)">
                    <animate attributeName="r" values="150;250;150" dur="8s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.02;0.05;0.02" dur="8s" repeatCount="indefinite"/>
                </circle>
                <circle cx="400" cy="300" r="100" fill="rgba(91,45,142,0.02)">
                    <animate attributeName="r" values="80;130;80" dur="10s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.02;0.04;0.02" dur="10s" repeatCount="indefinite"/>
                </circle>
                <circle cx="800" cy="500" r="120" fill="rgba(26,143,196,0.015)">
                    <animate attributeName="r" values="90;150;90" dur="12s" repeatCount="indefinite"/>
                    <animate attributeName="opacity" values="0.015;0.04;0.015" dur="12s" repeatCount="indefinite"/>
                </circle>
            </svg>
        </div>
        
        <div class="splash-loader-wrapper">
            <!-- Water Drop with Fill -->
            <div class="drop-container">
                <div class="water-drop">
                    <div class="drop-fill" id="dropFill"></div>
                    <i class="fas fa-water drop-icon"></i>
                </div>
            </div>
            
            <!-- Percentage -->
            <div class="splash-percentage">
                <span id="splashPercent">0</span><span class="percent-symbol">%</span>
            </div>
            
            <!-- Loading Text -->
            <div class="splash-loading-text">
                Loading<span class="dot">.</span><span class="dot">.</span><span class="dot">.</span>
            </div>
            
            <!-- Proceed Button -->
            <button class="splash-proceed-btn" id="proceedBtn">
                <i class="fas fa-water"></i> Proceed to Website
                <i class="fas fa-arrow-right"></i>
            </button>
        </div>
    </div>

    <!-- ============================================================
    NAVIGATION
    ============================================================ -->
    <nav class="landing-nav" id="navbar">
        <div class="brand">
            <div class="brand-icon"><i class="fas fa-water"></i></div>
            <span class="brand-text">Smart Water Guardian</span>
        </div>
        <button class="mobile-menu-btn" id="mobileMenuBtn" aria-label="Toggle menu">
            <i class="fas fa-bars"></i>
        </button>
        <div class="nav-actions" id="navActions">
            <a href="pages/login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
            <a href="pages/register.php" class="btn-register-nav"><i class="fas fa-user-plus"></i> Get Started</a>
        </div>
    </nav>

    <!-- ============================================================
    HERO SECTION
    ============================================================ -->
    <section class="hero" id="home">
        <div class="hero-content">
            <div class="hero-badge">
                <i class="fas fa-leaf"></i> Saving South Africa's Water
            </div>
            <h1>
                Monitor, Conserve, <br>
                <span class="highlight">Save Water</span> 
                <span class="highlight-green">in Real-Time</span>
            </h1>
            <p>
                Smart Water Guardian provides real-time monitoring, early leak detection, and 
                transparent water usage information to consumers and municipalities across South Africa.
            </p>
            <div class="hero-buttons">
                <a href="pages/register.php" class="btn btn-primary">
                    <i class="fas fa-rocket"></i> Get Started Free
                </a>
                <a href="#features" class="btn btn-outline">
                    <i class="fas fa-play-circle"></i> Learn More
                </a>
            </div>
            
            <div class="hero-stats">
                <div class="stat-item">
                    <span class="stat-number">
                        <span id="stat1">46</span><span class="percent">%</span>
                    </span>
                    <span class="stat-label"><i class="fas fa-tint"></i> Water Saved</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">
                        <span id="stat2">99</span><span class="percent">%</span>
                    </span>
                    <span class="stat-label"><i class="fas fa-search"></i> Leak Detection</span>
                </div>
                <div class="stat-item">
                    <span class="stat-number">
                        <span id="stat3">10</span>K<span class="percent">+</span>
                    </span>
                    <span class="stat-label"><i class="fas fa-users"></i> Active Users</span>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================
    TESTIMONIALS SECTION
    ============================================================ -->
    <section id="testimonials" class="testimonials-section">
        <div class="container">
            <div class="section-header">
                <h2>Real People, Real Stories</h2>
                <p>Hear how Smart Water Guardian is making a difference</p>
            </div>
            <div class="testimonials-grid">
                <!-- Testimonial 1 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-1">
                        <span>TM</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"Smart Water Guardian helped me detect a hidden leak in my garden that was costing me over R500 extra per month. I saved money and water!"</p>
                    <div class="author">Thandi Mokoena</div>
                    <div class="role">Homeowner, Soweto</div>
                </div>
                
                <!-- Testimonial 2 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-2">
                        <span>SN</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"As a municipal manager, I can now track water usage across our entire district in real-time. This system has revolutionized our water management."</p>
                    <div class="author">Sipho Ndlovu</div>
                    <div class="role">Municipal Manager, Tshwane</div>
                </div>
                
                <!-- Testimonial 3 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-3">
                        <span>LK</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"I received an alert about unusual water usage at 2 AM. I found a burst pipe before it caused serious damage. This system is a lifesaver!"</p>
                    <div class="author">Lerato Khumalo</div>
                    <div class="role">Business Owner, Durban</div>
                </div>
                
                <!-- Testimonial 4 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-4">
                        <span>DV</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"My water bill dropped by 40% in the first month! The usage analytics helped me understand where I was wasting water and change my habits."</p>
                    <div class="author">David van der Merwe</div>
                    <div class="role">Homeowner, Cape Town</div>
                </div>
                
                <!-- Testimonial 5 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-5">
                        <span>NZ</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"I love how easy it is to track my water usage. The alerts keep me informed and the community features connect me with like-minded neighbors."</p>
                    <div class="author">Nomsa Zulu</div>
                    <div class="role">Environmental Activist, Johannesburg</div>
                </div>
                
                <!-- Testimonial 6 -->
                <div class="testimonial-card">
                    <div class="avatar avatar-color-6">
                        <span>KM</span>
                    </div>
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <p class="quote">"The billing feature is a game-changer. I can see exactly what I'm paying for and the payment reminders help me stay on top of my bills."</p>
                    <div class="author">Kagiso Molefe</div>
                    <div class="role">Teacher, Pretoria</div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================
    FEATURES SECTION
    ============================================================ -->
    <section id="features" class="features-section">
        <div class="container">
            <div class="section-header">
                <h2>Smart Features for Smart Water Management</h2>
                <p>Everything you need to monitor and conserve water effectively</p>
            </div>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-microchip"></i></div>
                    <h3>IoT Smart Meters</h3>
                    <p>Real-time data collection with ESP32-powered smart meters for accurate water usage tracking.</p>
                </div>
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-cloud"></i></div>
                    <h3>Cloud Analytics</h3>
                    <p>Advanced anomaly detection and pattern recognition using cloud-based analytics.</p>
                </div>
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-bell"></i></div>
                    <h3>Instant Alerts</h3>
                    <p>Get notified immediately about leaks, high usage, and potential issues via multiple channels.</p>
                </div>
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-chart-bar"></i></div>
                    <h3>Usage Analytics</h3>
                    <p>Comprehensive charts and reports to understand your water consumption patterns.</p>
                </div>
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-mobile-alt"></i></div>
                    <h3>Cross-Platform</h3>
                    <p>Access your water data from any device - desktop, tablet, or mobile.</p>
                </div>
                <div class="feature-card">
                    <div class="icon-wrapper"><i class="fas fa-lock"></i></div>
                    <h3>Secure & Private</h3>
                    <p>POPIA compliant with enterprise-grade security for your water usage data.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================
    CTA SECTION
    ============================================================ -->
    <section class="cta-section">
        <div class="container">
            <h2>Ready to <span>Save Water</span> and <span>Save Money</span>?</h2>
            <p>Join thousands of South Africans who are already monitoring their water usage with Smart Water Guardian.</p>
            <a href="pages/register.php" class="btn">
                <i class="fas fa-user-plus"></i> Create Free Account
            </a>
        </div>
    </section>

    <!-- ============================================================
    FOOTER
    ============================================================ -->
    <footer class="footer">
        <div class="footer-links">
            <a href="#home">Home</a>
            <a href="#features">Features</a>
            <a href="#testimonials">Testimonials</a>
            <a href="pages/login.php">Login</a>
            <a href="pages/register.php">Register</a>
        </div>
        <p>&copy; 2026 Smart Water Guardian. All rights reserved.</p>
        <p style="font-size:14px;color:rgba(255,255,255,0.08);">
            Built for South Africa
        </p>
    </footer>

    <!-- ============================================================
    SCRIPTS
    ============================================================ -->
    <script>
        // ============================================================
        // SPLASH SCREEN - WATER DROPLET LOADING
        // ============================================================
        document.addEventListener('DOMContentLoaded', function() {
            const splashScreen = document.getElementById('splashScreen');
            const progressBar = document.getElementById('dropFill');
            const percentDisplay = document.getElementById('splashPercent');
            const proceedBtn = document.getElementById('proceedBtn');
            
            let progress = 0;
            let interval;
            
            function simulateLoading() {
                interval = setInterval(() => {
                    const increment = Math.floor(Math.random() * 5) + 1;
                    progress = Math.min(progress + increment, 100);
                    
                    progressBar.style.height = progress + '%';
                    percentDisplay.textContent = progress;
                    
                    if (progress >= 100) {
                        clearInterval(interval);
                        proceedBtn.classList.add('show');
                        
                        document.querySelector('.water-drop').style.animation = 'dropPulse 1s ease-in-out 3';
                        setTimeout(() => {
                            document.querySelector('.water-drop').style.animation = 'dropPulse 2s ease-in-out infinite';
                        }, 3000);
                    }
                }, 80);
            }
            
            simulateLoading();
            
            proceedBtn.addEventListener('click', function() {
                splashScreen.classList.add('hidden');
                document.body.style.overflow = 'auto';
                
                setTimeout(() => {
                    splashScreen.style.display = 'none';
                }, 1200);
            });
            
            document.body.style.overflow = 'hidden';
        });

        // ============================================================
        // NAVBAR SCROLL EFFECT
        // ============================================================
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // ============================================================
        // MOBILE MENU TOGGLE
        // ============================================================
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            const navActions = document.getElementById('navActions');
            navActions.classList.toggle('open');
            const icon = this.querySelector('i');
            if (navActions.classList.contains('open')) {
                icon.className = 'fas fa-times';
            } else {
                icon.className = 'fas fa-bars';
            }
        });

        document.querySelectorAll('#navActions a').forEach(link => {
            link.addEventListener('click', function() {
                document.getElementById('navActions').classList.remove('open');
                document.getElementById('mobileMenuBtn').querySelector('i').className = 'fas fa-bars';
            });
        });

        // ============================================================
        // COUNTING ANIMATION FOR STATS
        // ============================================================
        function animateCounter(elementId, target, duration) {
            duration = duration || 2000;
            const element = document.getElementById(elementId);
            if (!element) return;
            
            const start = 0;
            const startTime = Date.now();
            
            function update() {
                const elapsed = Date.now() - startTime;
                const progress = Math.min(elapsed / duration, 1);
                const current = Math.floor(progress * target);
                
                element.textContent = current;
                
                if (progress < 1) {
                    requestAnimationFrame(update);
                } else {
                    element.textContent = target;
                }
            }
            
            update();
        }

        // ============================================================
        // INTERSECTION OBSERVER FOR STATS
        // ============================================================
        document.addEventListener('DOMContentLoaded', function() {
            const statsSection = document.querySelector('.hero-stats');
            
            if (statsSection) {
                const observer = new IntersectionObserver(function(entries) {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            animateCounter('stat1', 46, 2000);
                            animateCounter('stat2', 99, 2000);
                            animateCounter('stat3', 10, 2000);
                            observer.disconnect();
                        }
                    });
                }, { threshold: 0.3 });
                
                observer.observe(statsSection);
            }
        });

        // ============================================================
        // SMOOTH SCROLL
        // ============================================================
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ 
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        console.log('Smart Water Guardian - Landing Page Loaded');
        console.log('Loading complete! Click Proceed to enter.');
    </script>
</body>
</html>